1. 编程题
   (06_homeWork\week04\student result: 06_homeWork\week04\studentMemoAndException.gif)

  基于学生信息管理系统增加以下两个功能：

            a.自定义学号异常类和年龄异常类，并在该成员变量不合理时产生异常对象并抛出。

            b.当系统退出时将 List 集合中所有学生信息写入到文件中，当系统启动时读取文件中所 有学生信息到 List 集合中。


2. 编程题
    (06_homeWork\week04\file  result: 06_homeWork\week04\fileTest.gif)
  实现将指定目录中的所有内容删除，包含子目录中的内容都要全部删除。


3. 编程题
    (06_homeWork\week04\maniFileViaTP   result: 06_homeWork\week04\fileCopybyTP.gif)
  使用线程池将一个目录中的所有内容拷贝到另外一个目录中，包含子目录中的内容。


4. 编程题
     (06_homeWork\week04\userMsg  result: 06_homeWork\week04\messageType.gif)

  使用基于 tcp 协议的编程模型实现将 UserMessage 类型对象由客户端发送给服务器；

  服 务 器接 收到 对象 后判 断 用户 对象 信息 是否 为 "admin" 和 "123456"， 若 是则 将 UserMessage 对象中的类型改为"success"，否则将类型改为"fail"并回发给客户端，客户 端接收到服务器发来的对象后判断并给出登录成功或者失败的提示。

  其中 UserMessage 类的特征有：类型(字符串类型) 和 用户对象(User 类型)。

  其中 User 类的特征有：用户名、密码(字符串类型)。

  如：

                UserMessage tum = new UserMessage("check", new User("admin", "123456"));


5. 编程题(仅实现 msg,  没有实现文件共享。  06_homeWork\week04\studentMemoAndException.gif     code： 06_homeWork\week04\chatRoom )

  使用基于 tcp 协议的编程模型实现多人同时在线聊天和传输文件，要求每个客户端将发 送的聊天内容和文件发送到服务器，服务器接收到后转发给当前所有在线的客户端。