package home_work.week04.student;

public class IdException  extends Exception{
    static final long serialVersionUID = -3387516993124229948L;

    public IdException(){
    }
    public  IdException(String message){
        super(message);
    }

}
