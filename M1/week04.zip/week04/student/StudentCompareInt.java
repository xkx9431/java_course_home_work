package home_work.week04.student;

public interface StudentCompareInt extends Comparable {

    public int compareTo(Student o);
}
